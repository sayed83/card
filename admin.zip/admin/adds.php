<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  
$query_class = query::g();
  if(admin::checkaccess($_SESSION[config::get('session/session_name')], 'adds.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
//error_reporting(0);
  include 'include/adds.php';
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			<?php if(isset($_GET['new'])){?>
				<div class="panel panel-default">
					<div class="panel-heading">
						Place New Ad
					</div>
					<div class="panel-body">
						<form action="<?php echo $_SERVER['REQUEST_URI']?>" method="post" class="form-inline" enctype="multipart/form-data" >
							<div class="form-group">
								<input type="hidden" name="type" value="2" class="" />
							</div>
							<div class="form-group">
								<!--<input type="text" name="script"  placeholder="script" class="form-control"  />-->
								<textarea name="script" ></textarea>
							</div>
							<div class="form-group">
								<input type="text" name="link" placeholder="link" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="file" name="file" placeholder="image" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="text" name="date"  id="datepicker"  value="<?php echo dates();?>" name="file" placeholder="image" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="submit" value="Insert " class="btn btn-success"   />
							</div>
						</form>
						
					</div>
				</div>
			<?php }else if(isset($_GET['edit'])){?>
				<div class="panel panel-default">
					<div class="panel-heading">
						Edit
					</div>
					<div class="panel-body">
						<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" class="form-inline" enctype="multipart/form-data" >
							<div class="form-group">
								<input type="hidden" type="link" value="2"   class="" />
							</div>
							<div class="form-group">
								<input type="text" name="edit_script" <?php echo 'value="'.get_table_data_single_row('adds','id',sanetize($_GET['edit']),'script').'"'; ?> placeholder="script" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="text" name="edit_link" <?php echo 'value="'.get_table_data_single_row('adds','id',sanetize($_GET['edit']),'link').'"'; ?> placeholder="link" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="file" name="edit_file" placeholder="image" class="form-control"  />
							</div>
							
							<div class="form-group">
								<input type="text" name="edit_date"  id="datepicker"  value="<?php echo dates();?>" name="file" placeholder="image" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="submit" value="Insert " class="btn btn-success"   />
							</div>
						</form>
						
					</div>
				</div>
			<?php }else if(isset($_GET['banner_edit'])){ 
			$id = sanetize($_GET['banner_edit']);
			?>
				<div class="panel panel-default">
					<div class="panel-heading">
						Edit
					</div>
					<div class="panel-body">
						<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" class="form-inline" enctype="multipart/form-data" >
							<div class="form-group">
								<input type="hidden" name="banner_edit_type" value="2"  />
								
							</div>
							<div class="form-group">
								<input type="hidden" name="banner_edit_script" <?php echo 'value="'.$query_class->query('single_data',array('`script`','banners','id','=',$id,'script')).'"'; ?> placeholder="script" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="text" name="banner_edit_link" <?php echo 'value="'.$query_class->query('single_data',array('`link`','banners','id','=',$id,'link')).'"'; ?> placeholder="link" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="file" name="banner_edit_file" placeholder="image" class="form-control"  />
							</div>
							
							<div class="form-group">
								<input type="text" name="banner_edit_date"  id="datepicker"  value="<?php echo other::dates();?>" name="file" placeholder="image" class="form-control"  />
							</div>
							<?php if(!empty($error)){echo $error[0];}?>
							<div class="form-group">
								<input type="submit" value="Insert " class="btn btn-success"   />
							</div>
						</form>
						
					</div>
				</div>
			<?php }?>
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Banner Adds</h4>
				</div>
				
				<div class="panel-body table-responsive">
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>AD Type</th>
							<th>Script</th>
							<th>Link</th>
							<th>Image Name</th>
							<th>Date</th>
							
						</tr>
						<?php 
						$data = $query_class->query('all_data_inv',array('banners','id'));
						foreach($data as $users){?>
							<tr>
								
								<td>
									<a href="adds.php?banner_edit=<?php echo $users['id'];?>" class="btn btn-success btn-xs" >Edit</a>
								</td>
								<td><?php 
								if($users['type'] == '1'){
									echo 'Script';
								}else if($users['type'] == '2'){
									echo 'Link';
								}
								?></td>
								<td><?php echo $users['script']?></td>
								<td><?php echo $users['link']?></td>
								<td><?php echo $users['image']?></td>
								<td><?php echo $users['date']?></td>
								
							</tr>
						<?php }?>
					</table>
				</div>
				
			</div>
			
		</div>
	</div>
<?php
  include 'include/footer.php';
?>