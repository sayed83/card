<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
 //print_r($_SESSION);

  if(admin::checkaccess($_SESSION[config::get('session/session_name')], 'orders.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
  $query_class = query::g();
  include 'include/orders.php';
?>
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Confirmation</h4>
		  </div>
		  <div class="modal-body">
			Do you want to Accept?
			<br />
			<br />
			<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" >
				<input type="hidden" name="orderid" id="orderid"   />
				<input type="submit" class="btn btn-success" value="Accept"   />
				<a href="<?php echo $_SERVER['REQUEST_URI'];?>" class="btn btn-danger pull-right"   >Close</a>
			</form>
		  </div>
		 
		</div>
	  </div>
	</div>
	<div class="container col-lg-10 col-md-10 col-sm-9 col-xs-12">
	 	<ul class="nav nav-tabs">
		  <li class="nav-item">
			<a class="nav-link active" href="orders">Dealers</a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link" href="st_orders">Stockiests</a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link" href="pr_orders">Premium</a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link" href="stn_orders">Standard</a>
		  </li>
		</ul>
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4>Order List </h4>
			</div>
			<div class="panel-body table-responsive">
				<table class="table table-bordered table-striped">
					<thead>
						<th>Status</th>
						<th>Contact No</th>
						<th>Delivery Address</th>
						<th>Vendor Number</th>
						<th>Date</th>
						<th>Time</th>
					</thead>
					<tbody>
						<?php 
						if(!isset($_GET['list'])){
						$products = page::g()->get_ten_data_all_dealers('orders');
						foreach($products as $product){?>
							<tr>
								<td class="" >
									<?php
									if($product['status'] == '0'){
										echo 'Pending';
									}else if($product['status'] == '1'){
										echo 'Accepted';
									}else if($product['status'] == '1'){
										echo 'Canceled';
									}
									?>
								</td>
								
								<td><?php echo $product['contact'];?></td>
								<td><?php echo $product['amount'];?></td>
								<td><?php echo $product['address'];?></td>
								<td><?php echo $product['token'];?></td>
								<td><?php echo $query_class->query('single_data',array('`number`','users','id','=',$product['delivery'],'number'));?></td>
								<td><?php echo $product['date'];?></td>
								<td><?php echo $product['time'];?></td>
								
							</tr>
							
						<?php }}else if(isset($_GET['list'])){
							$products = page::g()->paginationed_all_dealers(sanetize($_GET['list']),'orders');
							foreach($products as $product){
							?>
							<tr>
								<td class="" >
									<?php
									if($product['status'] == '0'){
										echo 'Pending';
									}else if($product['status'] == '1'){
										echo 'Order Placed';
									}else if($product['status'] == '2'){
										echo 'Canceled';
									}else if($product['status'] == '3'){
										echo 'Delivered';
									}else if($product['status'] == '4'){
										echo 'Received';
									}else if($product['status'] == '5'){
										echo 'Ignored';
									}else if($product['status'] == '6'){
										echo 'Returned';
									}else if($product['status'] == '7'){
										echo 'Return Received';
									}
									?>
								</td>
								
								<td><?php echo $product['contact'];?></td>
								<td><?php echo $product['amount'];?></td>
								<td><?php echo $product['address'];?></td>
								<td><?php echo $product['token'];?></td>
								<td><?php echo $query_class->query('single_data',array('`number`','users','id','=',$product['delivery'],'number'));?></td>
								<td><?php echo $product['date'];?></td>
								<td><?php echo $product['time'];?></td>
								
							</tr>
						<?php }} ?>
					</tbody>
				</table>
			</div>
			<div class="pull-right" aria-label="pagination">
				<ul class="pager">
				<?php
					error_reporting(0);
				  $count = 0;
				  
				  $rows = page::g()->pagination_list_all_dealers('orders');
				  if($rows > 1){
					for($count = 0; $count < $rows; $count++ ){?>
					<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="orders?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
				  <?php }}?>
				</ul>
			</div>
		</div>
	</div>
<?php

  include 'include/footer.php';
?>