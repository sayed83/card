<?php

class head{
	public static function to($location){
		header('Location:'.$location);
	}
}


?>