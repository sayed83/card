<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  $query_class = query::g();

  if(admin::checkaccess($_SESSION[config::get('session/session_name')], 'category.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}

	include 'include/category.php';
//error_reporting(0);

?>
	
	<div class="container col-md-10 col-sm-10"  >
		<div class="panel panel-default">
		
		<?php 
		if(isset($_GET['add_cat'])){?>
			<div class="panel-body">
				<form class="form-inline" action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" >
					<input type="text" name="add_cat" class="form-control" />
					<input type="submit" class="btn btn-success" value="Submit"  />
				</form>
			</div>
		<?php }else if(isset($_GET['edit_cat'])){
			$id = sanetize($_GET['edit_cat']);
			?>
			<div class="panel-body">
				<form class="form-inline" action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" >
					<input type="text" name="edit_cat" value="<?php echo $query_class->query('single_data',array('`name`','category','id','=',$id,'name'));?>"  class="form-control" />
					<input type="submit" class="btn btn-success" value="Submit"  />
				</form>
			</div>
		<?php } ?>
		</div>
		<div class="panel panel-default">
			<div class="panel-body">
				<div class="form-group form-inline">
					<a href="?add_cat=1" class="btn btn-success">Add New Category</a>
					
				</div>
				<table class="table" >
					<tr>
						<th>Category</th>
						
					</tr>
					<?php 
						$cats = $query_class->query('rows',array('`name`,`id`','category','type','=','cat'));
						foreach($cats as $cat){
					?>
				
					
					<tr>
						<td style="width:200px;" >
							<?php echo $cat['name'];?> <a href="?edit_cat=<?php echo $cat['id']?>" class="btn btn-success btn-xs" >Edit</a>
						</td>
					</tr>
				
					<?php }?>
				</table>	
			</div>
		</div>
	</div>
<?php
  include 'include/footer.php';
?>