<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
 

  if(admin::checkaccess($_SESSION[config::get('session/session_name')], 'products.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
  $query_class = query::g();
  
 
?>
	
	<div class="container col-lg-10 col-md-10 col-sm-9 col-xs-12">
	 	
		<?php include 'include/products.php';?>
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4>Product List <span class="pull-right"><a href="?new_product" class="btn btn-success" >New Product</a></span></h4> 
			</div>
			
			<div class="panel-body table-responsive">
				
				<table class="table table-bordered table-striped">
					<thead>
						<th>Action</th>
						<th>Name</th>
						<th>Catetory</th>
						<th>Images</th>
						<th>Price</th>
						<th>Stock</th>
						<th>Mrp</th>
						<th>Pv</th>
						<th>Code</th>
						<th>Short Details</th>
						
						
						
					</thead>
					<tbody >
						<?php 
						if(!isset($_GET['list'])){
						$products = page::g()->get_ten_data_all('products');
						foreach($products as $product){?>
							<tr>
								<td class="" width="150px" >
									<a href="?edit_product=<?php echo $product['id'];?>" class="badge badge-primary">Edit</a>
									<a href="?stock_update=<?php echo $product['id'];?>" class="badge badge-primary">Stock Update</a>
									<a href="?features=<?php echo $product['id'];?>" class="badge badge-primary">Add Features</a>
									<a href="?edit_features=<?php echo $product['id'];?>" class="badge badge-primary">Edit Features</a>
									<a href="?edit_images=<?php echo $product['id'];?>" class="badge badge-primary">Edit Images</a>
								</td>
								<td><?php echo $product['name'];?></td>
								<td><?php echo $query_class->query('single_data',array('`name`','category','id','=',$product['cat'],'name'));?></td>
								<td>
									<img width="80px"  src="../images/products/<?php echo $product['image_one'];?>" alt="" />
									<img width="80px"  src="../images/products/<?php echo $product['image_two'];?>" alt="" />
									<img width="80px"  src="../images/products/<?php echo $product['image_three'];?>" alt="" />
									<img width="80px"  src="../images/products/<?php echo $product['image_four'];?>" alt="" />
								</td>
								<td><?php echo $product['price'];?></td>
								<td><?php echo $product['stock'];?></td>
								<td><?php echo $product['mrp'];?></td>
								<td><?php echo $product['pv'];?></td>
								<td><?php echo $product['code'];?></td>
								<td><?php echo $product['short_details'];?></td>
								
							</tr>
							
						<?php }}else if(isset($_GET['list'])){
							$products = page::g()->paginationed_all(sanetize($_GET['list']),'products');
							foreach($products as $product){
							?>
							<tr>
								<td class="" width="150px" >
									<a href="?edit_product=<?php echo $product['id'];?>" class="badge badge-primary">Edit</a>
									<a href="?stock_update=<?php echo $product['id'];?>" class="badge badge-primary">Stock Update</a>
									<a href="?features=<?php echo $product['id'];?>" class="badge badge-primary">Add Features</a>
									<a href="?edit_features=<?php echo $product['id'];?>" class="badge badge-primary">Edit Features</a>
									<a href="?edit_images=<?php echo $product['id'];?>" class="badge badge-primary">Edit Images</a>
								</td>
								<td><?php echo $product['name'];?></td>
								<td><?php echo $query_class->query('single_data',array('`name`','category','id','=',$product['cat'],'name'));?></td>
								<td>
									<img width="80px"  src="../images/products/<?php echo $product['image_one'];?>" alt="" />
									<img width="80px"  src="../images/products/<?php echo $product['image_two'];?>" alt="" />
									<img width="80px"  src="../images/products/<?php echo $product['image_three'];?>" alt="" />
									<img width="80px"  src="../images/products/<?php echo $product['image_four'];?>" alt="" />
								</td>
								<td><?php echo $product['price'];?></td>
								<td><?php echo $product['stock'];?></td>
								<td><?php echo $product['mrp'];?></td>
								<td><?php echo $product['pv'];?></td>
								<td><?php echo $product['code'];?></td>
								<td><?php echo $product['short_details'];?></td>
								
							</tr>
						<?php }} ?>
					</tbody>
				</table>
				
			</div>
			<div class="pull-right" aria-label="pagination">
				<ul class="pager">
				<?php
					error_reporting(0);
				  $count = 0;
				  
				  $rows = page::g()->pagination_list_all('products');
				  if($rows > 1){
					for($count = 0; $count < $rows; $count++ ){?>
					<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="products.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
				  <?php }}?>
				</ul>
			</div>
		</div>
	</div>
<?php

  include 'include/footer.php';
?>