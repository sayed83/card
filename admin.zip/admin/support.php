<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  
$query_class = query::g();
  if(admin::checkaccess($_SESSION[config::get('session/session_name')], 'support.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
//error_reporting(0);
  //include 'include/offers.php';
  if(isset($_POST['reply'])){
	  $id = input::get('reply_id');
	  $uid = $query_class->query('single_data',array('uid','messages','id','=',$id,'uid'));
	  $reply = input::get('reply');
	  if(!empty($reply)){
		  $update = $query_class->insert('messages',array('sender'=>'admin','date'=>other::dates(),'time'=>other::times(),'message'=>$reply,'uid'=>$uid,'reply_for'=>$id));
		  head::to('support');
	  }
  }
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Support Tickets</h4>
				</div>
				
				<div class="panel-body table-responsive">
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Message</th>
							<th>Reply</th>
							
							
						</tr>
						<?php 
						$data = $query_class->multi_query(array('*','messages'),array("`sender` = 'user' ORDER BY `id` DESC LIMIT 50"));
						foreach($data as $users){?>
							<tr>
								
								<td style="width:400px;" >
									<?php if($users['sender'] == 'user'){echo $users['message'];}?>
								</td>
								
								<td>
									<?php
									$reply = $query_class->query('single_data',array('`message`','messages','reply_for','=',$users['id'],'message'));
									if(!empty($reply)){
										echo $reply;
									}else{?>
										<form class="" action="support" method="post"  >
											<input type="hidden" name="reply_id" value="<?php echo $users['id'];?>"   class="form-control" />
											<textarea name="reply" id="" cols="30" rows="10" class="form-control"></textarea>
											<input type="submit" class="btn btn-success reply_btn" value="Reply Now"  />
										</form>
									<?php }?>
								</td>
								
							</tr>
						<?php }?>
					</table>
				</div>
				
			</div>
			
		</div>
	</div>
<?php
  include 'include/footer.php';
?>