<?php
include 'include/head.php';

include 'include/header.php';
include 'include/nav.php';
  if(user::loggedin() == false){
	  header("Location:login.php");
  }
 
if(user::g()->checkaccess($_SESSION[config::get('session/session_name')], 'subadmin.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
function getalllist(){
	
	$sql = query::g()->query('rows',array('*','admin','number','=',''));
	$data = mysqli_fetch_field($sql);
	$names = array();
	while($name = mysqli_fetch_field($sql)){
	 $names[] = $name->name;
	}
	return $names;
}
if(isset($_GET['delete'])){
    $id = sanetize($_GET['delete']);
    $sql = mysqli_query(DB::g()->connect(), "DELETE FROM `admin` WHERE `id` = '$id'");
    if($sql == true){
        header('Location:subadmin.php');
    }
}
function adminlist(){
	
	$sql = mysqli_query(DB::g()->connect(), "SELECT * FROM `admin`");
	return $sql;
}
include 'api/createsubadmin.php';
?>
<div id="content" class="content-adjusted col-md-9" >
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">
				</div>
				<div class="panel-body">
					
					<div class="table-responsive overflowclass">
						<form action="subadmin.php" method="post" >
							<div class="col-md-12">
								<div class="col-md-3">Number</div>
								<div class="col-md-3"><input type="text" name="number" class="form-control"/></div>
								<div class="col-md-3">Password</div>
								<div class="col-md-3"><input type="text" name="password" class="form-control"/></div>
							</div>
							<br />
							<br />
							<div class="col-md-12">
							<ul>
									<?php foreach(getalllist() as $value){
										if($value !== 'account' && $value !== 'password' && $value !== 'number' ){
										?>
										
										<li class="col-md-4 creatsubadminlist" >
										    <input id="<?php echo $value;?>" type="checkbox" name="<?php echo $value;?>" value="<?php echo $value;?>" /> &nbsp;
										    <label for="<?php echo $value;?>"><?php echo $value;?></label> 
										</li>
									
									<?php }}?>
									</ul>	
								<br />
								<br />
								
								<div class="col-md-12">
									<div class="col-md-3">
										<input type="submit" class="btn btn-success form-control" value="Create Subadmin"/>
									</div>
								</div>
							</div>
							<br />
							<br />
						
								
					
						</form>
					</div>
					<br />
					<br />
				   <div class="table-responsive">
									
									<table class="table table-striped table-bordered" >
									    <tr>
									        <th>Number</th>
									        <th>Action</th>
									    </tr>
									   <?php 
									   $admindata = $query_class->query('all_data',array('admin'));
									   foreach($admindata as $admins){ 
									   if($admins['id'] !== '1'){
									   ?>
									     <tr>
									        <td><?php echo $admins['number']?></td>
									        <td><a href="subadmin.php?delete=<?php echo $admins['id']?>" >Remove</a></td>
									    </tr>
									   <?php }}?>
									</table>
									
								</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include 'include/footer.php';
?>